Name: WizardGo Plugin for Joomla (versions 1.7 to 2.5)
Description: This plugin automates implementation process of WizardGo Service on Joomla based websites.
License: GPLv2 
Version: 0.2 

Version: 0.2   

Requirements:
------------------------------------------------------------------------------
- Joomla Content Management System (versions from 1.7 to 2.5) 

Installation:
------------------------------------------------------------------------------   
1. Login to your Joomla administrator page.
2. Select the Extensions -> Install/Uninstall menu and upload the ".zip" file. 
3. Select the Extensions -> Plugin Manager and click on the "Content - WizardGo" 

Troubleshooting:
------------------------------------------------------------------------------
If you experience any problems with this plugin, feel free to contact us.
List of frequently asked question can be found here: http://www.wizardgo.com

